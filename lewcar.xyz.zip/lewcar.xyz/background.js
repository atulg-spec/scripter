chrome.runtime.onMessage.addListener((msg, sender) => {
    // First, validate the message's structure.
    if ((msg.from === 'content') && (msg.subject === 'showPageAction')) {
        // Enable the page-action for the requesting tab.
        chrome.pageAction.show(sender.tab.id);
        scroll(sender.tab.id);
        //

    }

    console.log(msg)
});



function scroll(id) {

    chrome.tabs.executeScript(id, {
        file: 'script.js'
        //If you had something somewhat more complex you can use an IIFE:
        //code: '(function (){return document.body.innerText;})();'
        //If your code was complex, you should store it in a
        // separate .js file, which you inject with the file: property.
    }, receiveText);
}

function receiveText(resultsArray) {

}