var time = 10;
var sTime = 0;
var finishedPer = 6;
var waitArr = 700;
var firstTime = 20000;

var body = document.body,
    html = document.documentElement;
var height = body.scrollHeight;


var link = [
    
    "https://lewcar.xyz/the-essential-guide-to-finding-the-best-car-accident-lawyer-near-you/",
    "https://lewcar.xyz/navigating-auto-injuries-finding-the-best-lawyer-near-you/",
    "https://lewcar.xyz/navigating-legal-waters-after-an-automobile-accident-finding-the-right-attorney-near-you/",
    "https://lewcar.xyz/the-importance-of-hiring-a-car-accident-attorney/",
    "https://lewcar.xyz/unveiling-the-essence-of-a-mesothelioma-law-firm-your-ultimate-guide-to-navigating-legal-waters/",
    "https://lewcar.xyz/finding-the-best-collision-lawyers-near-me-your-ultimate-guide/",
    "https://lewcar.xyz/navigating-car-accident-claims-why-you-need-a-specialized-lawyer/",
    "https://lewcar.xyz/the-ultimate-guide-to-finding-the-top-accident-lawyer/",
    "https://lewcar.xyz/get-the-compensation-you-deserve-finding-top-car-collision-lawyers-near-me/",
    "https://lewcar.xyz/the-ultimate-guide-to-finding-top-notch-motor-vehicle-accident-lawyers-near-you/",
    "https://lewcar.xyz/the-essential-guide-to-hiring-a-car-accident-attorney/",
    "https://lewcar.xyz/navigating-the-legal-maze-why-you-need-a-skilled-car-accident-lawyer-by-your-side/",
    

];


var currentLink = window.location.href;
var nextLink = "";




function next() {

    for (var i = 0; i < link.length; i++) {

        if (link[i] == currentLink) {
            if (i + 1 == link.length) {
                nextLink = "done";
            } else {
                nextLink = link[i + 1];
            }
        }

    }

    if (nextLink == "") nextLink = link[0];


}

setTimeout(() => {

    start(finishedPer)
    next();

}, firstTime);



function start(timeout) {

    setTimeout(() => {


        var scrollPos = window.scrollY || window.scrollTop || document.getElementsByTagName("html")[0].scrollTop;

        window.scrollTo(0, scrollPos + 10);

        if (window.innerHeight + scrollPos + 10 >= height) {
            console.log(window.innerHeight + scrollPos + 10);

            click();

        } else {

            if (time >= sTime) {

                start(finishedPer);
                sTime = sTime + 1;


            } else {


                sTime = 0;
                newStart();


            }

        }



    }, timeout);

}

function newStart() {

    setTimeout(() => {
        start(finishedPer);
    }, waitArr);

}


function click() {

    if (nextLink != "done") {

        var els = document.getElementsByTagName("a");
        for (var i = 0, l = els.length; i < l; i++) {
            var el = els[i];

            if (el.href === nextLink) {
                el.click();
            }
        }
    }
}


function shuffleArray(array) {
    for (var i = array.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    return array;
}